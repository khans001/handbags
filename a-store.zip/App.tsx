import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Product, Cart, SortOption, CartItem, Order, AdminUser } from './types';
import { PRODUCTS, CATEGORIES, SORT_OPTIONS } from './constants';
import Header from './components/Header';
import Controls from './components/Controls';
import ProductGrid from './components/ProductGrid';
import ProductModal from './components/ProductModal';
import CartSidebar from './components/CartSidebar';
import ProductFormModal from './components/ProductFormModal';
import CheckoutModal from './components/CheckoutModal';
import LoginModal from './components/LoginModal';
import OrdersModal from './components/OrdersModal';
import AdminManagementModal from './components/AdminManagementModal';
import CategoryManagementModal from './components/CategoryManagementModal';
import SiteNameModal from './components/SiteNameModal';

const initialAdmins: AdminUser[] = [
  { email: 'kingkhan00100923@gmail.com', password: 'iamawebdeveloper@001' }
];

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const savedProducts = localStorage.getItem('handbag_products');
      return savedProducts ? JSON.parse(savedProducts) : PRODUCTS;
    } catch (e) {
      return PRODUCTS;
    }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [sort, setSort] = useState<SortOption>('featured');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cart, setCart] = useState<Cart>(() => {
    try {
      const savedCart = localStorage.getItem('handbag_cart');
      return savedCart ? JSON.parse(savedCart) : {};
    } catch (e) {
      return {};
    }
  });

  // Category State
  const [categories, setCategories] = useState<string[]>(() => {
    try {
        const savedCategories = localStorage.getItem('handbag_categories');
        return savedCategories ? JSON.parse(savedCategories) : ['tote', 'clutch', 'crossbody', 'backpack', 'satchel', 'hobo bag', 'shoulder bag'];
    } catch (e) {
        return ['tote', 'clutch', 'crossbody', 'backpack', 'satchel', 'hobo bag', 'shoulder bag'];
    }
  });
  const [activeCategory, setActiveCategory] = useState('all');

  // Admin & Auth State
  const [admins, setAdmins] = useState<AdminUser[]>(() => {
    try {
      const savedAdmins = localStorage.getItem('handbag_admins');
      if (!savedAdmins || JSON.parse(savedAdmins).length === 0) {
        return initialAdmins;
      }
      return JSON.parse(savedAdmins);
    } catch (e) {
      return initialAdmins;
    }
  });
  const [loggedInAdmin, setLoggedInAdmin] = useState<string | null>(null);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAdminManagementOpen, setIsAdminManagementOpen] = useState(false);
  const [isCategoryManagementOpen, setIsCategoryManagementOpen] = useState(false);
  
  // Checkout & Orders State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isOrdersModalOpen, setIsOrdersModalOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const savedOrders = localStorage.getItem('handbag_orders');
      return savedOrders ? JSON.parse(savedOrders) : [];
    } catch (e) {
      return [];
    }
  });

  // Site Customization State
  const [websiteName, setWebsiteName] = useState<string>(() => {
    return localStorage.getItem('handbag_website_name') || 'Handbag Haven';
  });
  const [isSiteNameModalOpen, setIsSiteNameModalOpen] = useState(false);


  useEffect(() => {
    localStorage.setItem('handbag_admins', JSON.stringify(admins));
  }, [admins]);

  useEffect(() => {
    document.title = websiteName;
    localStorage.setItem('handbag_website_name', websiteName);
  }, [websiteName]);

  useEffect(() => {
    localStorage.setItem('handbag_categories', JSON.stringify(categories));
  }, [categories]);
  
  const isAdmin = !!loggedInAdmin;

  const updateProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    localStorage.setItem('handbag_products', JSON.stringify(newProducts));
  };

  const updateCart = (newCart: Cart) => {
    setCart(newCart);
    localStorage.setItem('handbag_cart', JSON.stringify(newCart));
  };
  
  const updateOrders = (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('handbag_orders', JSON.stringify(newOrders));
  }

  const handleUpdateWebsiteName = (newName: string) => {
    setWebsiteName(newName);
    setIsSiteNameModalOpen(false);
  };

  const filteredAndSortedProducts = useMemo(() => {
    let result = products
      .filter(p => activeCategory === 'all' || p.category === activeCategory)
      .filter(p =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase())
      );

    switch (sort) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'featured':
      default:
        break;
    }
    return result;
  }, [products, searchQuery, activeCategory, sort]);

  const handleAddToCart = useCallback((product: Product, quantity: number) => {
    const newCart = { ...cart };
    if (newCart[product.id]) {
      newCart[product.id].quantity += quantity;
    } else {
      newCart[product.id] = { ...product, quantity };
    }
    updateCart(newCart);
    setSelectedProduct(null);
    setIsCartOpen(true);
  }, [cart]);

  const handleUpdateQuantity = useCallback((productId: string, newQuantity: number) => {
    const newCart = { ...cart };
    if (newQuantity > 0) {
      if (newCart[productId]) {
        newCart[productId].quantity = newQuantity;
      }
    } else {
      delete newCart[productId];
    }
    updateCart(newCart);
  }, [cart]);
  
  const handleRemoveItem = useCallback((productId: string) => {
    const newCart = { ...cart };
    delete newCart[productId];
    updateCart(newCart);
  }, [cart]);

  const handleOpenProductForm = (product: Product | null) => {
    setEditingProduct(product);
    setIsProductFormOpen(true);
  };
  
  const handleCloseProductForm = () => {
    setEditingProduct(null);
    setIsProductFormOpen(false);
  };

  const handleSaveProduct = (productData: Omit<Product, 'id'>) => {
    if (editingProduct) {
      const newProducts = products.map(p => 
        p.id === editingProduct.id ? { ...p, ...productData } : p
      );
      updateProducts(newProducts);
    } else {
      const newProduct: Product = {
        id: `h${Date.now()}`,
        ...productData,
      };
      updateProducts([...products, newProduct]);
    }
    handleCloseProductForm();
  };
  
  const handleUpdateProductTitle = useCallback((productId: string, newTitle: string) => {
    if (!newTitle.trim()) {
        alert("Title cannot be empty.");
        return;
    }
    const newProducts = products.map(p => 
      p.id === productId ? { ...p, title: newTitle.trim() } : p
    );
    updateProducts(newProducts);
  }, [products]);

  const handleDeleteProduct = (productId: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      const newProducts = products.filter(p => p.id !== productId);
      updateProducts(newProducts);
    }
  };
  
  const handleExportData = () => {
    const dataToExport = {
        products: JSON.parse(localStorage.getItem('handbag_products') || JSON.stringify(PRODUCTS)),
        categories: JSON.parse(localStorage.getItem('handbag_categories') || JSON.stringify(CATEGORIES)),
        admins: JSON.parse(localStorage.getItem('handbag_admins') || JSON.stringify(initialAdmins)),
        orders: JSON.parse(localStorage.getItem('handbag_orders') || '[]'),
        websiteName: localStorage.getItem('handbag_website_name') || 'Handbag Haven'
    };
    
    const dataStr = JSON.stringify(dataToExport, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'handbag_haven_backup.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!window.confirm('Are you sure you want to import this data? This will overwrite ALL current products, categories, orders, admins, and settings.')) {
        event.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const text = e.target?.result;
            if (typeof text !== 'string') throw new Error('File content is not valid text.');
            
            const data = JSON.parse(text);

            if (!data.products || !data.categories || !data.admins || !data.orders || !data.websiteName) {
                throw new Error('Invalid data file. Missing required keys.');
            }

            updateProducts(data.products);
            setCategories(data.categories);
            localStorage.setItem('handbag_categories', JSON.stringify(data.categories));
            setAdmins(data.admins);
            localStorage.setItem('handbag_admins', JSON.stringify(data.admins));
            updateOrders(data.orders);
            setWebsiteName(data.websiteName);
            localStorage.setItem('handbag_website_name', data.websiteName);

            alert('Data imported successfully! The page will now reload to apply the changes.');
            window.location.reload();

        } catch (error: any) {
            console.error('Failed to import data:', error);
            alert(`Error importing data: ${error.message}`);
        } finally {
            event.target.value = '';
        }
    };
    reader.onerror = () => {
        alert('Failed to read the file.');
        event.target.value = '';
    };
    reader.readAsText(file);
  };

  const cartCount = useMemo(() => {
    return Object.values(cart).reduce((sum, item: CartItem) => sum + item.quantity, 0);
  }, [cart]);

  const cartItems = useMemo(() => Object.values(cart), [cart]);

  const handleCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handlePlaceOrder = (customerDetails: Order['customerDetails']) => {
    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      customerDetails,
      cartItems,
      total: cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0),
      createdAt: new Date().toISOString(),
      status: 'Pending',
    };

    updateOrders([...orders, newOrder]);
    
    alert('Thank you for your order! We will contact you shortly via email or WhatsApp to confirm the details.');
    
    updateCart({});
    setIsCheckoutOpen(false);
  };

  const handleLogin = (email: string, password: string) => {
    const admin = admins.find(a => a.email === email && a.password === password);
    if (admin) {
      setLoggedInAdmin(email);
      setIsLoginOpen(false);
    } else {
      alert('Invalid email or password.');
    }
  };

  const handleLogout = () => {
    setLoggedInAdmin(null);
  };

  const handleAdminClick = () => {
    if (isAdmin) {
      handleLogout();
    } else {
      setIsLoginOpen(true);
    }
  };
  
  const handleAddAdmin = (newAdmin: AdminUser) => {
    if (admins.some(a => a.email === newAdmin.email)) {
        alert('An admin with this email already exists.');
        return;
    }
    setAdmins(prev => [...prev, newAdmin]);
    alert('New admin added successfully!');
  };

  const handleDeleteAdmin = (emailToDelete: string) => {
    if (admins.length <= 1) {
        alert('You cannot delete the only admin account.');
        return;
    }
    if (window.confirm(`Are you sure you want to delete the admin: ${emailToDelete}?`)) {
        setAdmins(prev => prev.filter(a => a.email !== emailToDelete));
    }
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    const newOrders = orders.map(o => o.id === orderId ? { ...o, status } : o);
    updateOrders(newOrders);
  };

  // Category Management Handlers
  const handleAddCategory = (name: string) => {
    const newName = name.trim().toLowerCase();
    if (!newName) {
      alert('Category name cannot be empty.');
      return;
    }
    if (categories.some(c => c.toLowerCase() === newName)) {
      alert('This category already exists.');
      return;
    }
    setCategories(prev => [...prev, name.trim()]);
  };
  
  const handleUpdateCategory = (oldName: string, newName: string) => {
    const trimmedNewName = newName.trim();
    if (!trimmedNewName) {
        alert('Category name cannot be empty.');
        return;
    }
    if (categories.some(c => c.toLowerCase() === trimmedNewName.toLowerCase() && c.toLowerCase() !== oldName.toLowerCase())) {
        alert('Another category with this name already exists.');
        return;
    }
    // Update category in products
    const newProducts = products.map(p => p.category === oldName ? { ...p, category: trimmedNewName } : p);
    updateProducts(newProducts);

    // Update category in categories list
    setCategories(prev => prev.map(c => c === oldName ? trimmedNewName : c));
  };
  
  const handleDeleteCategory = (name: string) => {
    const isCategoryInUse = products.some(p => p.category === name);
    if (isCategoryInUse) {
      alert(`Cannot delete "${name}" because it is currently assigned to one or more products. Please re-assign them first.`);
      return;
    }
    if (window.confirm(`Are you sure you want to delete the category "${name}"?`)) {
      setCategories(prev => prev.filter(c => c !== name));
      if (activeCategory === name) {
        setActiveCategory('all');
      }
    }
  };


  return (
    <div className="min-h-screen flex flex-col">
      <Header
        websiteName={websiteName}
        onSearchChange={setSearchQuery}
        cartCount={cartCount}
        onCartClick={() => setIsCartOpen(true)}
        isAdmin={isAdmin}
        onAdminClick={handleAdminClick}
      />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <Controls
          categories={['all', ...categories]}
          sortOptions={SORT_OPTIONS}
          onCategoryChange={setActiveCategory}
          onSortChange={(val) => setSort(val as SortOption)}
          isAdmin={isAdmin}
          onAddProductClick={() => handleOpenProductForm(null)}
          onExportDataClick={handleExportData}
          onImportDataChange={handleImportData}
          onViewOrdersClick={() => setIsOrdersModalOpen(true)}
          onManageAdminsClick={() => setIsAdminManagementOpen(true)}
          onManageCategoriesClick={() => setIsCategoryManagementOpen(true)}
          onEditSiteNameClick={() => setIsSiteNameModalOpen(true)}
        />
        <ProductGrid
          products={filteredAndSortedProducts}
          onProductClick={setSelectedProduct}
          isAdmin={isAdmin}
          onEditProduct={handleOpenProductForm}
          onDeleteProduct={handleDeleteProduct}
          onUpdateProductTitle={handleUpdateProductTitle}
        />
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        {websiteName} &copy; {new Date().getFullYear()}
      </footer>

      {isLoginOpen && <LoginModal 
        onClose={() => setIsLoginOpen(false)} 
        onLogin={handleLogin} 
      />}

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}
      
      {isAdmin && isProductFormOpen && (
        <ProductFormModal
          product={editingProduct}
          onClose={handleCloseProductForm}
          onSave={handleSaveProduct}
          categories={categories}
        />
      )}
      
      {isAdmin && isAdminManagementOpen && (
        <AdminManagementModal
            isOpen={isAdminManagementOpen}
            onClose={() => setIsAdminManagementOpen(false)}
            admins={admins}
            currentUserEmail={loggedInAdmin!}
            onAddAdmin={handleAddAdmin}
            onDeleteAdmin={handleDeleteAdmin}
        />
      )}
      
      {isAdmin && isCategoryManagementOpen && (
        <CategoryManagementModal
            isOpen={isCategoryManagementOpen}
            onClose={() => setIsCategoryManagementOpen(false)}
            categories={categories}
            onAddCategory={handleAddCategory}
            onUpdateCategory={handleUpdateCategory}
            onDeleteCategory={handleDeleteCategory}
        />
      )}

      {isCheckoutOpen && (
        <CheckoutModal 
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          onPlaceOrder={handlePlaceOrder}
          cartItems={cartItems}
        />
      )}

      {isAdmin && isOrdersModalOpen && (
        <OrdersModal
            isOpen={isOrdersModalOpen}
            onClose={() => setIsOrdersModalOpen(false)}
            orders={orders}
            onUpdateStatus={handleUpdateOrderStatus}
        />
      )}

      {isAdmin && isSiteNameModalOpen && (
        <SiteNameModal
          isOpen={isSiteNameModalOpen}
          onClose={() => setIsSiteNameModalOpen(false)}
          onSave={handleUpdateWebsiteName}
          currentName={websiteName}
        />
      )}

      <CartSidebar
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckoutClick={handleCheckout}
      />
    </div>
  );
};

export default App;