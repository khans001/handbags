import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: "h1",
    title: "The All-Day Leather Tote",
    price: 189.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1594223274502-9421bcc4a46a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h2",
    title: "Chic Vegan Crossbody",
    price: 79.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-162092120-411552b78997?auto=format&fit=crop&q=80&w=764"
  },
  {
    id: "h3",
    title: "Sequin Party Clutch",
    price: 59.99,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1566150905458-1bf1f2997647?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h4",
    title: "Urban Explorer Backpack",
    price: 120.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1553062407-98eeb68c6a62?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h5",
    title: "Riviera Straw Tote",
    price: 69.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1587317228919-8488e17096d3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h6",
    title: "Minimalist Leather Satchel",
    price: 145.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1610290495277-248232935275?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h7",
    title: "Slouchy Hobo Bag",
    price: 95.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1621341142009-5c0245084a4a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h8",
    title: "Everyday Shoulder Bag",
    price: 88.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h9",
    title: "The Commuter Backpack",
    price: 155.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1577733935215-68a7c0c163ed?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h10",
    title: "Elegant Envelope Clutch",
    price: 49.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1618632623793-3f6c8914850c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h11",
    title: "Quilted Chain Crossbody",
    price: 110.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1599948123714-2d2c10461877?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h12",
    title: "Canvas Market Tote",
    price: 45.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h13",
    title: "Woven Market Tote",
    price: 75.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1620921204543-98207a670359?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h14",
    title: "Downtown Chic Backpack",
    price: 135.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1581655353362-e7f0f8d12d4f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h15",
    title: "Midnight Velvet Clutch",
    price: 65.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1631061916194-524a1e9a7e1c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h16",
    title: "Saddle Leather Crossbody",
    price: 99.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1605733513596-2a7815541be7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h17",
    title: "Professional Laptop Tote",
    price: 210.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1590858903560-5a359e802373?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h18",
    title: "Casual Canvas Satchel",
    price: 85.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614163956794-27204459d2a2?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h19",
    title: "Boho Fringe Hobo",
    price: 105.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1598532163419-8879555a1cc7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h20",
    title: "Classic Top-Handle Bag",
    price: 160.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1604018321074-b8686a38618e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h21",
    title: "Mini Bucket Bag",
    price: 92.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1627539233090-0433c267a14f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h22",
    title: "Adventure Seeker Backpack",
    price: 140.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1622058382498-a729e16f7a6f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h23",
    title: "Geometric Beaded Clutch",
    price: 78.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1590737233810-2e5f3851b43d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h24",
    title: "The City Slicker Tote",
    price: 195.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1589156191108-c24c3a812b2b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h25",
    title: "Sleek Camera Bag",
    price: 89.99,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1617344983999-661f00b73a98?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h26",
    title: "Executive Leather Briefcase",
    price: 250.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614769611326-21f083d65b1d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h27",
    title: "Weekender Duffel Bag",
    price: 180.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1576884887399-a4a58f4a6e4e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h28",
    title: "Ruched Shoulder Bag",
    price: 98.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614163964235-d7350f03102c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h29",
    title: "Boxy Patent Clutch",
    price: 55.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1616041284483-d3bd5b4b4a1a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h30",
    title: "Pebbled Leather Crossbody",
    price: 115.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1612543632454-3253b8f75b24?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h31",
    title: "Nylon Commuter Backpack",
    price: 110.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1591812239324-f7a9985935a4?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h32",
    title: "Soft Suede Hobo",
    price: 130.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1608231387042-8a84e8689713?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h33",
    title: "Structured Work Tote",
    price: 220.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1617454214220-413158c55845?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h34",
    title: "The Parisian Satchel",
    price: 175.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1619118357592-2c262145893f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h35",
    title: "Braided Handle Shoulder Bag",
    price: 108.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614251649934-84c67858c42b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h36",
    title: "Metallic Evening Clutch",
    price: 72.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1589578236294-6d9b54c03c5b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h37",
    title: "Convertible Belt Bag",
    price: 68.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1575233140193-45525547926b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h38",
    title: "Leather-Trimmed Canvas Tote",
    price: 125.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1606524933748-2781a8ec5a1b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h39",
    title: "Foldover Crossbody",
    price: 82.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1615842813636-22a4503a5543?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h40",
    title: "Multi-Pocket Utility Backpack",
    price: 165.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1605342461872-97211516e5f3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h41",
    title: "Vintage All-Day Leather Tote",
    price: 199.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1594223274502-9421bcc4a46a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h42",
    title: "Vintage Chic Vegan Crossbody",
    price: 89.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-162092120-411552b78997?auto=format&fit=crop&q=80&w=764"
  },
  {
    id: "h43",
    title: "Vintage Sequin Party Clutch",
    price: 69.99,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1566150905458-1bf1f2997647?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h44",
    title: "Vintage Urban Explorer Backpack",
    price: 130.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1553062407-98eeb68c6a62?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h45",
    title: "Vintage Riviera Straw Tote",
    price: 79.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1587317228919-8488e17096d3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h46",
    title: "Vintage Minimalist Leather Satchel",
    price: 155.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1610290495277-248232935275?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h47",
    title: "Vintage Slouchy Hobo Bag",
    price: 105.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1621341142009-5c0245084a4a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h48",
    title: "Vintage Everyday Shoulder Bag",
    price: 98.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h49",
    title: "Vintage Commuter Backpack",
    price: 165.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1577733935215-68a7c0c163ed?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h50",
    title: "Vintage Elegant Envelope Clutch",
    price: 59.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1618632623793-3f6c8914850c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h51",
    title: "Vintage Quilted Chain Crossbody",
    price: 120.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1599948123714-2d2c10461877?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h52",
    title: "Vintage Canvas Market Tote",
    price: 55.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h53",
    title: "Vintage Woven Market Tote",
    price: 85.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1620921204543-98207a670359?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h54",
    title: "Vintage Downtown Chic Backpack",
    price: 145.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1581655353362-e7f0f8d12d4f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h55",
    title: "Vintage Midnight Velvet Clutch",
    price: 75.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1631061916194-524a1e9a7e1c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h56",
    title: "Vintage Saddle Leather Crossbody",
    price: 109.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1605733513596-2a7815541be7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h57",
    title: "Vintage Professional Laptop Tote",
    price: 220.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1590858903560-5a359e802373?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h58",
    title: "Vintage Casual Canvas Satchel",
    price: 95.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614163956794-27204459d2a2?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h59",
    title: "Vintage Boho Fringe Hobo",
    price: 115.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1598532163419-8879555a1cc7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h60",
    title: "Vintage Classic Top-Handle Bag",
    price: 170.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1604018321074-b8686a38618e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h61",
    title: "Vintage Mini Bucket Bag",
    price: 102.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1627539233090-0433c267a14f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h62",
    title: "Vintage Adventure Seeker Backpack",
    price: 150.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1622058382498-a729e16f7a6f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h63",
    title: "Vintage Geometric Beaded Clutch",
    price: 88.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1590737233810-2e5f3851b43d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h64",
    title: "Vintage City Slicker Tote",
    price: 205.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1589156191108-c24c3a812b2b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h65",
    title: "Vintage Sleek Camera Bag",
    price: 99.99,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1617344983999-661f00b73a98?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h66",
    title: "Vintage Executive Leather Briefcase",
    price: 260.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614769611326-21f083d65b1d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h67",
    title: "Vintage Weekender Duffel Bag",
    price: 190.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1576884887399-a4a58f4a6e4e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h68",
    title: "Vintage Ruched Shoulder Bag",
    price: 108.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614163964235-d7350f03102c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h69",
    title: "Vintage Boxy Patent Clutch",
    price: 65.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1616041284483-d3bd5b4b4a1a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h70",
    title: "Vintage Pebbled Leather Crossbody",
    price: 125.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1612543632454-3253b8f75b24?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h71",
    title: "Vintage Nylon Commuter Backpack",
    price: 120.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1591812239324-f7a9985935a4?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h72",
    title: "Vintage Soft Suede Hobo",
    price: 140.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1608231387042-8a84e8689713?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h73",
    title: "Vintage Structured Work Tote",
    price: 230.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1617454214220-413158c55845?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h74",
    title: "Vintage Parisian Satchel",
    price: 185.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1619118357592-2c262145893f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h75",
    title: "Vintage Braided Handle Shoulder Bag",
    price: 118.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614251649934-84c67858c42b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h76",
    title: "Vintage Metallic Evening Clutch",
    price: 82.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1589578236294-6d9b54c03c5b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h77",
    title: "Vintage Convertible Belt Bag",
    price: 78.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1575233140193-45525547926b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h78",
    title: "Vintage Leather-Trimmed Canvas Tote",
    price: 135.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1606524933748-2781a8ec5a1b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h79",
    title: "Vintage Foldover Crossbody",
    price: 92.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1615842813636-22a4503a5543?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h80",
    title: "Vintage Multi-Pocket Utility Backpack",
    price: 175.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1605342461872-97211516e5f3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h81",
    title: "Modern All-Day Leather Tote",
    price: 179.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1594223274502-9421bcc4a46a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h82",
    title: "Modern Chic Vegan Crossbody",
    price: 69.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-162092120-411552b78997?auto=format&fit=crop&q=80&w=764"
  },
  {
    id: "h83",
    title: "Modern Sequin Party Clutch",
    price: 49.99,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1566150905458-1bf1f2997647?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h84",
    title: "Modern Urban Explorer Backpack",
    price: 110.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1553062407-98eeb68c6a62?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h85",
    title: "Modern Riviera Straw Tote",
    price: 59.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1587317228919-8488e17096d3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h86",
    title: "Modern Minimalist Leather Satchel",
    price: 135.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1610290495277-248232935275?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h87",
    title: "Modern Slouchy Hobo Bag",
    price: 85.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1621341142009-5c0245084a4a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h88",
    title: "Modern Everyday Shoulder Bag",
    price: 78.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h89",
    title: "Modern Commuter Backpack",
    price: 145.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1577733935215-68a7c0c163ed?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h90",
    title: "Modern Elegant Envelope Clutch",
    price: 39.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1618632623793-3f6c8914850c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h91",
    title: "Modern Quilted Chain Crossbody",
    price: 100.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1599948123714-2d2c10461877?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h92",
    title: "Modern Canvas Market Tote",
    price: 35.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h93",
    title: "Modern Woven Market Tote",
    price: 65.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1620921204543-98207a670359?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h94",
    title: "Modern Downtown Chic Backpack",
    price: 125.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1581655353362-e7f0f8d12d4f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h95",
    title: "Modern Midnight Velvet Clutch",
    price: 55.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1631061916194-524a1e9a7e1c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h96",
    title: "Modern Saddle Leather Crossbody",
    price: 89.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1605733513596-2a7815541be7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h97",
    title: "Modern Professional Laptop Tote",
    price: 200.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1590858903560-5a359e802373?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h98",
    title: "Modern Casual Canvas Satchel",
    price: 75.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614163956794-27204459d2a2?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h99",
    title: "Modern Boho Fringe Hobo",
    price: 95.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1598532163419-8879555a1cc7?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h100",
    title: "Modern Classic Top-Handle Bag",
    price: 150.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1604018321074-b8686a38618e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h101",
    title: "Modern Mini Bucket Bag",
    price: 82.50,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1627539233090-0433c267a14f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h102",
    title: "Modern Adventure Seeker Backpack",
    price: 130.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1622058382498-a729e16f7a6f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h103",
    title: "Modern Geometric Beaded Clutch",
    price: 68.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1590737233810-2e5f3851b43d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h104",
    title: "Modern City Slicker Tote",
    price: 185.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1589156191108-c24c3a812b2b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h105",
    title: "Modern Sleek Camera Bag",
    price: 79.99,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1617344983999-661f00b73a98?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h106",
    title: "Modern Executive Leather Briefcase",
    price: 240.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1614769611326-21f083d65b1d?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h107",
    title: "Modern Weekender Duffel Bag",
    price: 170.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1576884887399-a4a58f4a6e4e?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h108",
    title: "Modern Ruched Shoulder Bag",
    price: 88.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614163964235-d7350f03102c?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h109",
    title: "Modern Boxy Patent Clutch",
    price: 45.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1616041284483-d3bd5b4b4a1a?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h110",
    title: "Modern Pebbled Leather Crossbody",
    price: 105.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1612543632454-3253b8f75b24?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h111",
    title: "Modern Nylon Commuter Backpack",
    price: 100.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1591812239324-f7a9985935a4?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h112",
    title: "Modern Soft Suede Hobo",
    price: 120.00,
    category: "hobo bag",
    image: "https://images.unsplash.com/photo-1608231387042-8a84e8689713?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h113",
    title: "Modern Structured Work Tote",
    price: 210.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1617454214220-413158c55845?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h114",
    title: "Modern Parisian Satchel",
    price: 165.00,
    category: "satchel",
    image: "https://images.unsplash.com/photo-1619118357592-2c262145893f?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h115",
    title: "Modern Braided Handle Shoulder Bag",
    price: 98.00,
    category: "shoulder bag",
    image: "https://images.unsplash.com/photo-1614251649934-84c67858c42b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h116",
    title: "Modern Metallic Evening Clutch",
    price: 62.00,
    category: "clutch",
    image: "https://images.unsplash.com/photo-1589578236294-6d9b54c03c5b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h117",
    title: "Modern Convertible Belt Bag",
    price: 58.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1575233140193-45525547926b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h118",
    title: "Modern Leather-Trimmed Canvas Tote",
    price: 115.00,
    category: "tote",
    image: "https://images.unsplash.com/photo-1606524933748-2781a8ec5a1b?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h119",
    title: "Modern Foldover Crossbody",
    price: 72.00,
    category: "crossbody",
    image: "https://images.unsplash.com/photo-1615842813636-22a4503a5543?auto=format&fit=crop&q=80&w=870"
  },
  {
    id: "h120",
    title: "Modern Multi-Pocket Utility Backpack",
    price: 155.00,
    category: "backpack",
    image: "https://images.unsplash.com/photo-1605342461872-97211516e5f3?auto=format&fit=crop&q=80&w=870"
  }
];

export const CATEGORIES = ['all', 'tote', 'clutch', 'crossbody', 'backpack', 'satchel', 'hobo bag', 'shoulder bag'];

export const SORT_OPTIONS = [
    { value: 'featured', label: 'Featured' },
    { value: 'price-asc', label: 'Price: Low to High' },
    { value: 'price-desc', label: 'Price: High to Low' },
];
