import React, { useState } from 'react';
import { AdminUser } from '../types';

interface AdminManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  admins: AdminUser[];
  currentUserEmail: string;
  onAddAdmin: (admin: AdminUser) => void;
  onDeleteAdmin: (email: string) => void;
}

const DeleteIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);


const AdminManagementModal: React.FC<AdminManagementModalProps> = ({ isOpen, onClose, admins, currentUserEmail, onAddAdmin, onDeleteAdmin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
        alert("Please enter both email and password.");
        return;
    }
    onAddAdmin({ email, password });
    setEmail('');
    setPassword('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Manage Admins</h2>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl" aria-label="Close">&times;</button>
        </div>
        <div className="flex-grow overflow-y-auto p-6 space-y-8">
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-4 border-b pb-2">Add New Admin</h3>
                <form onSubmit={handleAddSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                    <div className="md:col-span-1">
                        <label htmlFor="newAdminEmail" className="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" id="newAdminEmail" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-accent-dark sm:text-sm" />
                    </div>
                    <div className="md:col-span-1">
                        <label htmlFor="newAdminPassword" className="block text-sm font-medium text-gray-700">Password</label>
                        <input type="password" id="newAdminPassword" value={password} onChange={(e) => setPassword(e.target.value)} required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-accent-dark sm:text-sm" />
                    </div>
                    <div className="md:col-span-1">
                        <button type="submit" className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-accent hover:bg-accent-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark">Add Admin</button>
                    </div>
                </form>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-4 border-b pb-2">Current Admins</h3>
                <div className="space-y-3">
                    {admins.map(admin => (
                        <div key={admin.email} className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
                            <span className="text-gray-800">{admin.email}</span>
                            <button
                                onClick={() => onDeleteAdmin(admin.email)}
                                disabled={admin.email === currentUserEmail}
                                className="p-2 text-red-600 rounded-full hover:bg-red-100 disabled:text-gray-400 disabled:hover:bg-transparent focus:outline-none focus:ring-2 focus:ring-red-500 disabled:cursor-not-allowed"
                                aria-label={`Delete admin ${admin.email}`}
                            >
                                <DeleteIcon className="h-5 w-5" />
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdminManagementModal;