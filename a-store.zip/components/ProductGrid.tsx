import React from 'react';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface ProductGridProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  isAdmin: boolean;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onUpdateProductTitle: (productId: string, newTitle: string) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({ products, onProductClick, isAdmin, onEditProduct, onDeleteProduct, onUpdateProductTitle }) => {
  return (
    <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      {products.map(product => (
        <ProductCard 
            key={product.id} 
            product={product} 
            onProductClick={onProductClick}
            isAdmin={isAdmin}
            onEdit={onEditProduct}
            onDelete={onDeleteProduct}
            onUpdateTitle={onUpdateProductTitle}
        />
      ))}
    </section>
  );
};

export default ProductGrid;