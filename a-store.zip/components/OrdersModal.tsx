import React from 'react';
import { Order } from '../types';

interface OrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
}

const getStatusColor = (status: Order['status']) => {
  switch (status) {
    case 'Pending':
      return 'bg-yellow-100 text-yellow-800';
    case 'Shipped':
      return 'bg-blue-100 text-blue-800';
    case 'Completed':
      return 'bg-green-100 text-green-800';
    case 'Cancelled':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const OrdersModal: React.FC<OrdersModalProps> = ({ isOpen, onClose, orders, onUpdateStatus }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-4xl h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Customer Orders</h2>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl" aria-label="Close">&times;</button>
        </div>
        <div className="flex-grow overflow-y-auto p-4">
          {orders.length === 0 ? (
            <p className="text-center text-gray-500 mt-8">No orders have been placed yet.</p>
          ) : (
            <div className="space-y-4">
              {orders.slice().reverse().map(order => (
                <div key={order.id} className="border rounded-lg p-4">
                  <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-2">
                    <div>
                      <p className="font-bold text-lg">Order #{order.id.split('_')[1]}</p>
                      <p className="text-sm text-gray-500">{new Date(order.createdAt).toLocaleString()}</p>
                    </div>
                    <div className="mt-2 sm:mt-0">
                      <select
                        value={order.status}
                        onChange={(e) => onUpdateStatus(order.id, e.target.value as Order['status'])}
                        className={`text-sm font-medium py-1 px-2 rounded-full border-none focus:ring-2 focus:ring-accent ${getStatusColor(order.status)}`}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>
                  <div className="text-sm space-y-1 mt-2 pt-2 border-t">
                    <p><strong>Name:</strong> {order.customerDetails.firstName} {order.customerDetails.lastName}</p>
                    <p><strong>Email:</strong> {order.customerDetails.email}</p>
                    <p><strong>Phone:</strong> {order.customerDetails.phone}</p>
                    <p><strong>Address:</strong> {order.customerDetails.address}, {order.customerDetails.city}, {order.customerDetails.country} {order.customerDetails.postalCode || ''}</p>
                    {order.customerDetails.landmark && <p><strong>Landmark:</strong> {order.customerDetails.landmark}</p>}
                  </div>
                  <div className="mt-2 pt-2 border-t">
                    <h4 className="font-semibold mb-1">Items:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-700">
                      {order.cartItems.map(item => (
                        <li key={item.id}>{item.title} x {item.quantity} - (${(item.price * item.quantity).toFixed(2)})</li>
                      ))}
                    </ul>
                  </div>
                   <div className="text-right font-bold text-lg mt-2">
                        Total: ${order.total.toFixed(2)}
                    </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default OrdersModal;