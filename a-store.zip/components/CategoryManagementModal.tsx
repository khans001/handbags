import React, { useState } from 'react';

interface CategoryManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: string[];
  onAddCategory: (name: string) => void;
  onUpdateCategory: (oldName: string, newName: string) => void;
  onDeleteCategory: (name: string) => void;
}

const EditIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" />
    </svg>
);
const DeleteIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);
const CheckIcon: React.FC<{className?: string}> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
);


const CategoryManagementModal: React.FC<CategoryManagementModalProps> = ({ 
    isOpen, 
    onClose, 
    categories, 
    onAddCategory, 
    onUpdateCategory, 
    onDeleteCategory 
}) => {
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddCategory(newCategoryName);
    setNewCategoryName('');
  };

  const handleEditClick = (name: string) => {
    setEditingCategory(name);
    setEditingValue(name);
  };

  const handleSaveEdit = (oldName: string) => {
    onUpdateCategory(oldName, editingValue);
    setEditingCategory(null);
    setEditingValue('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Manage Categories</h2>
          <button type="button" onClick={onClose} className="text-gray-500 hover:text-gray-800 text-2xl" aria-label="Close">&times;</button>
        </div>
        <div className="flex-grow overflow-y-auto p-6 space-y-6">
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Add New Category</h3>
                <form onSubmit={handleAddSubmit} className="flex gap-2">
                    <input 
                        type="text" 
                        value={newCategoryName} 
                        onChange={(e) => setNewCategoryName(e.target.value)} 
                        placeholder="e.g., Tote, Clutch"
                        className="flex-grow border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-accent-dark sm:text-sm" 
                    />
                    <button type="submit" className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-accent hover:bg-accent-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark">Add</button>
                </form>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">Current Categories</h3>
                <div className="space-y-2">
                    {categories.map(cat => (
                        <div key={cat} className="flex justify-between items-center p-2 bg-gray-50 rounded-md">
                            {editingCategory === cat ? (
                                <input 
                                    type="text" 
                                    value={editingValue} 
                                    onChange={(e) => setEditingValue(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSaveEdit(cat)}
                                    autoFocus
                                    className="flex-grow border-b-2 border-accent bg-transparent focus:outline-none"
                                />
                            ) : (
                                <span className="text-gray-800 capitalize">{cat}</span>
                            )}
                            <div className="flex items-center gap-2">
                                {editingCategory === cat ? (
                                    <button
                                        onClick={() => handleSaveEdit(cat)}
                                        className="p-2 text-green-600 rounded-full hover:bg-green-100 focus:outline-none focus:ring-2 focus:ring-green-500"
                                        aria-label={`Save change for ${cat}`}
                                    >
                                        <CheckIcon className="h-5 w-5" />
                                    </button>
                                ) : (
                                     <button
                                        onClick={() => handleEditClick(cat)}
                                        className="p-2 text-blue-600 rounded-full hover:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        aria-label={`Edit ${cat}`}
                                    >
                                        <EditIcon className="h-5 w-5" />
                                    </button>
                                )}
                                <button
                                    onClick={() => onDeleteCategory(cat)}
                                    className="p-2 text-red-600 rounded-full hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-500"
                                    aria-label={`Delete ${cat}`}
                                >
                                    <DeleteIcon className="h-5 w-5" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
        <div className="p-4 bg-gray-50 border-t flex justify-end">
             <button type="button" onClick={onClose} className="py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-dark">Done</button>
        </div>
      </div>
    </div>
  );
};

export default CategoryManagementModal;